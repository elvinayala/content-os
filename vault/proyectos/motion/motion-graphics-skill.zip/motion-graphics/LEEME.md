# Motion graphics · paquete (Level Up Media · 27/sep/2026)

Método y taller con los que se produjeron 80+ anuncios de motion (Level Up, Bori, AI Borinquen, Ritmo, 1000X).
Contenido PREMIUM: se puede aplicar para clientes (lanzamientos, logo animado, recorridos de app, anuncios).

- `SKILL.md` — el método completo (skill `motion-graphics` de Claude Code).
- `cerebro-remi.md` — criterio del motion designer (principios, reglas de marca, cómo revisa y entrega).
- `max-motion.md` — cómo lo aplica Max como estratega digital para clientes.
- `taller/` — el proyecto Remotion: `src/fabrica/` (anuncios en datos, escenas, temas por marca),
  `src/marcas/` (logos animados), `scripts/` (audio por prompt, render por lotes, hoja de contacto, entrega).

## Montarlo
```bash
cd taller && npm i            # Remotion 4 + fuentes
npx remotion studio src/index.ts        # previsualizar
scripts/render-fabrica.sh <id>          # renderizar → out/fabrica/<id>.mp4
node scripts/hoja.mjs <id>              # revisar (1 cuadro por escena)
```
La música y los efectos no vienen en el paquete: se generan con `scripts/audio.mjs` (fal.ai) y van en
`public/audio/`. Las capturas de apps y las tomas de Higgsfield tampoco (ver SKILL.md §1–§2).
